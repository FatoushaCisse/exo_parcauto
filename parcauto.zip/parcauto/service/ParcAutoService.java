package parcauto.service;

import parcauto.model.Entretien;
import parcauto.model.EtatVehicule;
import parcauto.model.Vehicule;

import java.util.*;
import java.util.stream.Collectors;


public class ParcAutoService {


    /** Source de vérité ordonnée */
    private final List<Vehicule>          vehicules          = new ArrayList<>();

    /** Index rapide immatriculation → Vehicule */
    private final Map<String, Vehicule>   indexParImmat      = new HashMap<>();

    // ÉTAPE 8 — Map<Long, List<Entretien>> : données liées multi-niveau

    /** Un véhicule peut avoir 0..N entretiens */
    private final Map<Long, List<Entretien>> entretiensParVehiculeId = new HashMap<>();

    // ÉTAPE 6 — Insertion / suppression avec cohérence List + Map


    /**
     * Ajoute un véhicule.
     * Maintient la cohérence List ↔ Map en une seule opération atomique.
     *
     * @throws IllegalArgumentException si l'immatriculation existe déjà
     */
    public void ajouterVehicule(Vehicule v) {
        Objects.requireNonNull(v, "Vehicule ne peut pas être null");
        String immat = normaliser(v.getImmatriculation());

        if (indexParImmat.containsKey(immat)) {
            throw new IllegalArgumentException(
                    "Immatriculation déjà présente : " + v.getImmatriculation());
        }

        vehicules.add(v);               // ajout en queue de liste
        indexParImmat.put(immat, v);    // indexation simultanée
    }

    /**
     * Supprime un véhicule par immatriculation.
     * Retire de la List ET de la Map pour rester cohérent.
     * @return le véhicule supprimé, ou empty si absent
     */
    public Optional<Vehicule> supprimerVehicule(String immat) {
        String cle = normaliser(immat);
        Vehicule v = indexParImmat.remove(cle);  // O(1)
        if (v != null) {
            vehicules.remove(v);                 // O(n) acceptable sur List
            entretiensParVehiculeId.remove(v.getId()); // nettoyage entretiens liés
        }
        return Optional.ofNullable(v);
    }

    /**
     * Recherche un véhicule par immatriculation — O(1) grâce à la Map.
     */
    public Optional<Vehicule> rechercher(String immat) {
        return Optional.ofNullable(indexParImmat.get(normaliser(immat)));
    }



    /**
     * Retourne un Set dédupliqué des véhicules.
     * Grâce à equals/hashCode sur immatriculation, deux objets avec la même
     * immat comptent comme un seul.
     */
    public Set<Vehicule> vehiculesUniques() {
        return new HashSet<>(vehicules);
    }



    /**
     * Enregistre un entretien.
     * computeIfAbsent crée la liste seulement si elle n'existe pas encore.
     */
    public void ajouterEntretien(Entretien e) {
        Objects.requireNonNull(e, "Entretien null");
        entretiensParVehiculeId
                .computeIfAbsent(e.getVehiculeId(), id -> new ArrayList<>())
                .add(e);
    }

    /**
     * Retourne les entretiens d'un véhicule — jamais null, liste vide si aucun.
     */
    public List<Entretien> getEntretiens(Long vehiculeId) {
        return entretiensParVehiculeId.getOrDefault(vehiculeId, Collections.emptyList());
    }



    /** Véhicules disponibles (filter) */
    public List<Vehicule> vehiculesDisponibles() {
        return vehicules.stream()
                .filter(v -> v.getEtat() == EtatVehicule.DISPONIBLE)
                .collect(Collectors.toList());
    }

    /** Immatriculations triées alphabétiquement (map + sorted) */
    public List<String> immatriculationsTriees() {
        return vehicules.stream()
                .map(Vehicule::getImmatriculation)
                .sorted()
                .collect(Collectors.toList());
    }

    /** Les 3 véhicules avec le plus grand kilométrage (sorted desc + limit) */
    public List<Vehicule> top3Kilometrage() {
        return vehicules.stream()
                .sorted(Comparator.comparingInt(Vehicule::getKilometrage).reversed())
                .limit(3)
                .collect(Collectors.toList());
    }


    /** Kilométrage moyen de la flotte */
    public OptionalDouble kilometrageMoyen() {
        return vehicules.stream()
                .mapToInt(Vehicule::getKilometrage)
                .average();
    }

    /** Nombre de véhicules par état */
    public Map<EtatVehicule, Long> nombreParEtat() {
        return vehicules.stream()
                .collect(Collectors.groupingBy(
                        Vehicule::getEtat,
                        Collectors.counting()
                ));
    }

    /**
     * Total des coûts d'entretien par véhicule (id → somme en €).
     * Utilise la Map d'entretiens déjà construite.
     */
    public Map<Long, Integer> coutTotalEntretiensParVehicule() {
        return entretiensParVehiculeId.entrySet().stream()
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        e -> e.getValue().stream()
                                .mapToInt(Entretien::getCoutEuros)
                                .sum()
                ));
    }


    // Utilitaires

    /** Normalise une immatriculation pour les comparaisons (insensible à la casse) */
    private static String normaliser(String immat) {
        return immat == null ? null : immat.trim().toUpperCase();
    }

    /** Accesseur en lecture seule sur la liste complète */
    public List<Vehicule> getTousLesVehicules() {
        return Collections.unmodifiableList(vehicules);
    }
}
