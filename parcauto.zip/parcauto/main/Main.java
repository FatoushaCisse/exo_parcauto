package parcauto.main;

import parcauto.model.Entretien;
import parcauto.model.EtatVehicule;
import parcauto.model.Vehicule;
import parcauto.service.ParcAutoService;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Point d'entrée de démonstration — Étapes 6 à 10.
 * Chaque section est clairement délimitée et commentée.
 */
public class Main {

    public static void main(String[] args) {

        ParcAutoService service = new ParcAutoService();

        // Données de test
        Vehicule v1 = new Vehicule(1L, "AB-123-CD", "Renault", "Clio",   45_000, EtatVehicule.DISPONIBLE);
        Vehicule v2 = new Vehicule(2L, "EF-456-GH", "Peugeot", "308",   120_000, EtatVehicule.EN_LOCATION);
        Vehicule v3 = new Vehicule(3L, "IJ-789-KL", "Citroën", "C3",     30_000, EtatVehicule.DISPONIBLE);
        Vehicule v4 = new Vehicule(4L, "MN-012-OP", "Toyota",  "Yaris", 200_000, EtatVehicule.EN_MAINTENANCE);
        Vehicule v5 = new Vehicule(5L, "QR-345-ST", "BMW",     "Serie3", 80_000, EtatVehicule.DISPONIBLE);

        // ÉTAPE 6 — List + Map cohérentes
        titre("ÉTAPE 6 — List + Map");

        service.ajouterVehicule(v1);
        service.ajouterVehicule(v2);
        service.ajouterVehicule(v3);
        service.ajouterVehicule(v4);
        service.ajouterVehicule(v5);

        System.out.println("Recherche 'EF-456-GH' : " + service.rechercher("EF-456-GH"));
        System.out.println("Recherche 'XX-000-XX' : " + service.rechercher("XX-000-XX"));

        service.supprimerVehicule("MN-012-OP");
        System.out.println("Après suppression MN-012-OP, total : "
                + service.getTousLesVehicules().size() + " véhicules");

        // Tentative de doublon → exception attendue
        try {
            service.ajouterVehicule(new Vehicule(99L, "AB-123-CD", "Doublon", "Test", 0, EtatVehicule.DISPONIBLE));
        } catch (IllegalArgumentException ex) {
            System.out.println("Exception doublon Map : " + ex.getMessage());
        }

        System.out.println();

        // ÉTAPE 7 — Set + identité métier (equals/hashCode)

        titre("ÉTAPE 7 — Set + unicité immatriculation");

        // On recrée un objet distinct mais même immat → ne doit PAS s'ajouter
        Vehicule v1Doublon = new Vehicule(100L, "AB-123-CD", "Doublon", "Same", 999, EtatVehicule.HORS_SERVICE);

        Set<Vehicule> uniques = service.vehiculesUniques();
        System.out.println("Taille Set avant ajout doublon : " + uniques.size());

        uniques.add(v1Doublon);   // même immatriculation que v1
        System.out.println("Taille Set après tentative doublon : " + uniques.size()
                + " (inchangée grâce à equals/hashCode)");

        System.out.println("v1.equals(v1Doublon) : " + v1.equals(v1Doublon)
                + "  |  hashCodes identiques : " + (v1.hashCode() == v1Doublon.hashCode()));

        System.out.println();

        // ÉTAPE 8 — Map<Long, List<Entretien>>
        titre("ÉTAPE 8 — Entretiens par véhicule");

        Entretien e1 = new Entretien(1L, 1L, LocalDate.of(2024, 3, 15), "Vidange", 120);
        Entretien e2 = new Entretien(2L, 1L, LocalDate.of(2024, 9, 20), "Plaquettes de frein", 280);
        Entretien e3 = new Entretien(3L, 2L, LocalDate.of(2024, 6, 10), "Révision complète", 450);

        service.ajouterEntretien(e1);
        service.ajouterEntretien(e2);
        service.ajouterEntretien(e3);

        System.out.println("Entretiens véhicule 1 :");
        service.getEntretiens(1L).forEach(e -> System.out.println("  " + e));

        System.out.println("Entretiens véhicule 2 :");
        service.getEntretiens(2L).forEach(e -> System.out.println("  " + e));

        System.out.println("Entretiens véhicule 99 (inexistant) : "
                + service.getEntretiens(99L) + " ← liste vide, jamais null");

        System.out.println();

        // ÉTAPE 9 — Streams (1)

        titre("ÉTAPE 9 — Streams : filter / map / sorted / limit");

        System.out.println("Véhicules disponibles :");
        service.vehiculesDisponibles()
               .forEach(v -> System.out.println("  " + v));

        System.out.println("\nImmatriculations triées :");
        service.immatriculationsTriees()
               .forEach(i -> System.out.println("  " + i));

        System.out.println("\nTop 3 kilométrage :");
        service.top3Kilometrage()
               .forEach(v -> System.out.printf("  %-15s %,d km%n",
                       v.getImmatriculation(), v.getKilometrage()));

        System.out.println();


        // ÉTAPE 10 — Streams (2) : stats

        titre("ÉTAPE 10 — Streams : stats");

        service.kilometrageMoyen().ifPresent(moy ->
                System.out.printf("Kilométrage moyen : %,.0f km%n", moy));

        System.out.println("\nNombre de véhicules par état :");
        service.nombreParEtat()
               .forEach((etat, nb) ->
                       System.out.printf("  %-18s → %d%n", etat, nb));

        System.out.println("\nCoût total d'entretien par véhicule (id) :");
        service.coutTotalEntretiensParVehicule()
               .forEach((id, cout) ->
                       System.out.printf("  Véhicule #%d → %d €%n", id, cout));
    }


    private static void titre(String texte) {
        System.out.println("─".repeat(60));
        System.out.println("  " + texte);
        System.out.println("─".repeat(60));
    }
}
