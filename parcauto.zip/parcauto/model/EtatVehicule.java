package parcauto.model;

/** États possibles d'un véhicule dans le parc. */
public enum EtatVehicule {
    DISPONIBLE,
    EN_LOCATION,
    EN_MAINTENANCE,
    HORS_SERVICE
}
