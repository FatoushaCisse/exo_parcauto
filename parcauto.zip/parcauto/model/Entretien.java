package parcauto.model;

import java.time.LocalDate;
import java.util.Objects;

/**
 * Représente un entretien effectué sur un véhicule.
 * Lié à un véhicule via vehiculeId (clé étrangère logique).
 */
public class Entretien {

    private final Long      id;
    private final Long      vehiculeId;     // référence vers Vehicule.id
    private final LocalDate date;
    private final String    description;
    private final int       coutEuros;

    public Entretien(Long id, Long vehiculeId, LocalDate date,
                     String description, int coutEuros) {
        this.id          = id;
        this.vehiculeId  = Objects.requireNonNull(vehiculeId);
        this.date        = Objects.requireNonNull(date);
        this.description = description;
        this.coutEuros   = coutEuros;
    }

    public Long      getId()          { return id; }
    public Long      getVehiculeId()  { return vehiculeId; }
    public LocalDate getDate()        { return date; }
    public String    getDescription() { return description; }
    public int       getCoutEuros()   { return coutEuros; }

    @Override
    public String toString() {
        return String.format("Entretien{id=%d, vehiculeId=%d, date=%s, '%s', %d€}",
                id, vehiculeId, date, description, coutEuros);
    }
}
