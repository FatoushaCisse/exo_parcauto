package parcauto.model;

import java.util.Objects;

/**
 * Entité métier représentant un véhicule du parc.
 * ÉTAPE 7 — equals/hashCode basés sur l'immatriculation (identité métier).
 * L'immatriculation est l'identifiant naturel unique d'un véhicule.
 */
public class Vehicule {

    // Champs

    private final Long    id;
    private final String  immatriculation;   // clé d'identité métier
    private final String  marque;
    private final String  modele;
    private       int     kilometrage;
    private       EtatVehicule etat;

    // Constructeur

    public Vehicule(Long id, String immatriculation, String marque,
                    String modele, int kilometrage, EtatVehicule etat) {
        this.id             = id;
        this.immatriculation = Objects.requireNonNull(immatriculation,
                                "L'immatriculation est obligatoire");
        this.marque         = marque;
        this.modele         = modele;
        this.kilometrage    = kilometrage;
        this.etat           = etat;
    }



    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Vehicule)) return false;
        Vehicule v = (Vehicule) o;
        return immatriculation.equalsIgnoreCase(v.immatriculation);
    }

    @Override
    public int hashCode() {
        // On normalise en majuscules pour rester cohérent avec equals (ignore case)
        return Objects.hash(immatriculation.toUpperCase());
    }


    // Accesseurs

    public Long         getId()             { return id; }
    public String       getImmatriculation(){ return immatriculation; }
    public String       getMarque()         { return marque; }
    public String       getModele()         { return modele; }
    public int          getKilometrage()    { return kilometrage; }
    public EtatVehicule getEtat()           { return etat; }

    public void setKilometrage(int kilometrage) { this.kilometrage = kilometrage; }
    public void setEtat(EtatVehicule etat)      { this.etat = etat; }

    @Override
    public String toString() {
        return String.format("Vehicule{id=%d, immat='%s', %s %s, %d km, %s}",
                id, immatriculation, marque, modele, kilometrage, etat);
    }
}
